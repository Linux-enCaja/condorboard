The fpga.h file in this directory is used for getting started design for AT91CAP7-STk board only
since PIOB is used to connect to LEDs through FPGA for this board only.  